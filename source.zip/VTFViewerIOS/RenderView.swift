import SwiftUI

// Аналог RenderActivity: читает байты файла, кодирует в base64, отдаёт в WebView
struct RenderView: View {
    let fileURL: URL

    @State private var base64: String?
    @State private var errorMessage: String?

    var body: some View {
        Group {
            if let base64 {
                VTFWebView(base64: base64)
                    .ignoresSafeArea(edges: .bottom)
            } else if let errorMessage {
                Text("Ошибка: \(errorMessage)")
                    .foregroundStyle(.red)
                    .padding()
            } else {
                ProgressView("Загрузка...")
            }
        }
        .navigationTitle(fileURL.lastPathComponent)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear(perform: loadFile)
    }

    private func loadFile() {
        // fileImporter / onOpenURL отдают security-scoped URL — доступ нужно явно открыть/закрыть
        let needsSecurityScope = fileURL.startAccessingSecurityScopedResource()
        defer {
            if needsSecurityScope {
                fileURL.stopAccessingSecurityScopedResource()
            }
        }

        do {
            let data = try Data(contentsOf: fileURL)
            base64 = data.base64EncodedString()
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
