import SwiftUI
import WebKit

// Аналог vtf_webview из RenderActivity.
// Грузит vtf_viewer.html из бандла и дергает ту же самую JS-функцию loadVtfFromBase64.
struct VTFWebView: UIViewRepresentable {
    let base64: String

    func makeUIView(context: Context) -> WKWebView {
        let webView = WKWebView()
        webView.backgroundColor = .black
        webView.isOpaque = false
        webView.navigationDelegate = context.coordinator

        if let htmlURL = Bundle.main.url(forResource: "vtf_viewer", withExtension: "html") {
            // loadFileURL даёт доступ к папке ресурсов, чтобы <script src="vtf.bundle.js"> подгрузился
            webView.loadFileURL(htmlURL, allowingReadAccessTo: htmlURL.deletingLastPathComponent())
        }

        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(base64: base64)
    }

    class Coordinator: NSObject, WKNavigationDelegate {
        let base64: String
        init(base64: String) {
            self.base64 = base64
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            // Красим body, как в оригинале, и грузим VTF
            webView.evaluateJavaScript(
                "document.body.style.backgroundColor = 'black'; document.body.style.color = 'white';"
            )
            webView.evaluateJavaScript("loadVtfFromBase64('\(base64)')") { _, error in
                if let error {
                    print("JS error: \(error)")
                }
            }
        }
    }
}
