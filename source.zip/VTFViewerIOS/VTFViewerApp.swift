import SwiftUI

@main
struct VTFViewerApp: App {
    // Путь к файлу, который прилетел через "Open in..." (файловая ассоциация .vtf)
    @State private var incomingURL: URL?

    var body: some Scene {
        WindowGroup {
            ContentView(incomingURL: $incomingURL)
                .onOpenURL { url in
                    incomingURL = url
                }
        }
    }
}
