import SwiftUI
import UniformTypeIdentifiers

// Аналог MainActivity: кнопка выбора файла + переход на просмотр
struct ContentView: View {
    @Binding var incomingURL: URL?

    @State private var showPicker = false
    @State private var selectedURL: URL?
    @State private var showRenderScreen = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 24) {
                Image(systemName: "photo.on.rectangle.angled")
                    .font(.system(size: 56))
                    .foregroundStyle(.secondary)

                Text("VTF Viewer")
                    .font(.title2.bold())

                Button {
                    showPicker = true
                } label: {
                    Label("Выбрать VTF файл", systemImage: "folder")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .padding(.horizontal, 40)
            }
            .navigationDestination(isPresented: $showRenderScreen) {
                if let selectedURL {
                    RenderView(fileURL: selectedURL)
                }
            }
            // Аналог ACTION_GET_CONTENT / startActivityForResult(fp, REQ_CD_FP)
            .fileImporter(
                isPresented: $showPicker,
                allowedContentTypes: [.item],
                allowsMultipleSelection: false
            ) { result in
                switch result {
                case .success(let urls):
                    if let url = urls.first {
                        openFile(url)
                    }
                case .failure(let error):
                    print("File pick failed: \(error)")
                }
            }
            // Аналог ImportfileActivity: файл открыт извне (Files app / "Открыть в...")
            .onChange(of: incomingURL) { _, newValue in
                if let newValue {
                    openFile(newValue)
                }
            }
        }
    }

    private func openFile(_ url: URL) {
        // Для security-scoped URL (из fileImporter/Files) нужен доступ до чтения байт в RenderView
        selectedURL = url
        showRenderScreen = true
    }
}

#Preview {
    ContentView(incomingURL: .constant(nil))
}
